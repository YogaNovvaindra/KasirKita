-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2021 at 02:05 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_bangunan`
--

-- --------------------------------------------------------

--
-- Table structure for table `akun`
--

CREATE TABLE `akun` (
  `id_pengguna` varchar(6) NOT NULL,
  `password` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `akun`
--

INSERT INTO `akun` (`id_pengguna`, `password`) VALUES
('admin', 'admin'),
('kasir', 'kasir');

-- --------------------------------------------------------

--
-- Table structure for table `anggota`
--

CREATE TABLE `anggota` (
  `id_pengguna` varchar(6) NOT NULL,
  `nama_anggota` varchar(30) NOT NULL,
  `alamat_anggota` varchar(80) NOT NULL,
  `telp_anggota` char(12) NOT NULL,
  `tipe_anggota` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `anggota`
--

INSERT INTO `anggota` (`id_pengguna`, `nama_anggota`, `alamat_anggota`, `telp_anggota`, `tipe_anggota`) VALUES
('admin', 'Admin', '', '', 'admin'),
('kasir', 'Kasir', '', '', 'kasir');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` varchar(6) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah` double NOT NULL,
  `id_satuan` varchar(6) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `id_sup` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `jumlah`, `id_satuan`, `harga_jual`, `harga_beli`, `id_sup`) VALUES
('ABJ001', 'Asbes Jabesmen 150x105', 498, 'lbr', 40000, 35000, 'S00006'),
('ABJ002', 'Asbes Jabesmen 180x105', 498, 'lbr', 45000, 40000, 'S00006'),
('ABJ003', 'Asbes Jabesmen 210x105', 498, 'lbr', 50000, 45000, 'S00006'),
('ABJ004', 'Asbes Jabesmen 240x105', 490, 'lbr', 55500, 50500, 'S00006'),
('ABJ005', 'Asbes Jabesmen 270x105', 473, 'lbr', 65000, 60000, 'S00006'),
('ABJ006', 'Asbes Jabesmen 300x105', 484, 'lbr', 75000, 70000, 'S00006'),
('BSB001', 'Besi Beton (6 mm)', 500, 'pcs', 26000, 11000, 'S00008'),
('BSB002', 'Besi Beton (8 mm)', 500, 'pcs', 35000, 20000, 'S00008'),
('BSB003', 'Besi Beton (10 mm)', 500, 'pcs', 50000, 35000, 'S00008'),
('BSB004', 'Besi Beton (12 mm)', 500, 'pcs', 70000, 55000, 'S00008'),
('BTB001', 'Batu Bata Merah (Biasa)', 474, 'pcs', 500, 450, 'S00007'),
('BTB002', 'Batu Bata Merah (Oven)', 490, 'pcs', 650, 600, 'S00007'),
('CTC001', 'Cat Catylac (5 kg)', 500, 'kg', 110000, 95000, 'S00008'),
('CTM001', 'Cat Metrolite (5 kg)', 500, 'kg', 90000, 75000, 'S00008'),
('CTV001', 'Cat Vinillex (5 kg)', 500, 'kg', 112000, 97000, 'S00008'),
('KCB001', 'Kaca Bening Tebal (3 mm)', 490, 'm2', 80000, 75000, 'S00005'),
('KCB002', 'Kaca Bening Tebal (5 mm)', 489, 'm2', 87500, 82500, 'S00005'),
('KCB003', 'Kaca Bening Tebal (8 mm) ', 489, 'm2', 140000, 135000, 'S00005'),
('KCB004', 'Kaca Piring Tebal (10 mm)', 495, 'm2', 200000, 195000, 'S00005'),
('KCR001', 'Kaca Rayben Tebal (3 mm)', 499, 'm2', 65000, 60000, 'S00005'),
('KCR002', 'Kaca Rayben Tebal (5 mm)', 498, 'm2', 62500, 57500, 'S00005'),
('KCR003', 'Kaca Rayben Tebal (6 mm)', 496, 'm2', 125000, 120000, 'S00005'),
('KCR004', 'Kaca Rayben Tebal (8 mm)', 499, 'm2', 220000, 215000, 'S00005'),
('PBH001', 'Paku Beton Hitam uk. 3 cm', 498, 'kg', 17500, 12500, 'S00003'),
('PBH002', 'Paku Beton Hitam uk. 5 cm', 498, 'kg', 16000, 11000, 'S00003'),
('PBH003', 'Paku Beton Hitam uk. 7 cm', 499, 'kg', 14000, 9000, 'S00003'),
('PBP001', 'Paku Beton Putih uk. 2.5 cm', 499, 'kg', 34000, 29000, 'S00003'),
('PBP002', 'Paku Beton Putih uk. 3 cm', 497, 'kg', 34000, 29000, 'S00003'),
('PBP003', 'Paku Beton Putih uk. 4 cm', 498, 'kg', 34000, 29000, 'S00003'),
('PBP004', 'Paku Beton Putih uk. 5 cm', 487, 'kg', 34000, 29000, 'S00003'),
('PBP005', 'Paku Beton Putih uk. 6 cm', 500, 'kg', 32000, 27000, 'S00003'),
('PBP006', 'Paku Beton Putih uk. 7 cm', 498, 'kg', 32000, 27000, 'S00003'),
('PBP007', 'Paku Beton Putih uk. 10 cm', 499, 'kg', 32000, 27000, 'S00003'),
('PBP008', 'Paku Beton Putih uk. 12.5 cm', 500, 'kg', 32000, 27000, 'S00003'),
('PKY001', 'Paku Kayu uk. 2 cm', 500, 'kg', 18000, 13000, 'S00002'),
('PKY002', 'Paku Kayu uk. 2.5 cm', 500, 'kg', 17000, 12000, 'S00002'),
('PKY003', 'Paku Kayu uk. 3 cm', 499, 'kg', 16000, 11000, 'S00002'),
('PKY004', 'Paku Kayu uk. 4 cm', 500, 'kg', 15000, 10000, 'S00002'),
('PKY005', 'Paku Kayu uk. 5 cm', 497, 'kg', 14000, 9000, 'S00002'),
('PKY006', ' Paku Kayu uk. 7 cm', 500, 'kg', 14000, 9000, 'S00002'),
('PKY007', 'Paku Kayu uk. 10 cm', 500, 'kg', 14000, 9000, 'S00002'),
('PSC001', 'Pasir Cileungsi', 499, 'm3', 200000, 195000, 'S00007'),
('PSM001', 'Pasir Mundu', 500, 'm3', 250000, 245000, 'S00007'),
('PSP001', 'Pasir Putih Bangka', 500, 'm3', 265000, 260000, 'S00007'),
('PWA001', 'Pipa PVC Wavin Aw 0.50', 500, 'btg', 13500, 8500, 'S00009'),
('PWA002', 'Pipa PVC Wavin Aw 0.75', 500, 'btg', 18900, 13400, 'S00009'),
('PWA003', 'Pipa PVC Wavin Aw 1.00', 500, 'btg', 26300, 21300, 'S00009'),
('PWD001', 'Pipa PVC Wavin D 1.50', 500, 'btg', 28500, 13500, 'S00009'),
('PWD002', 'Pipa PVC Wavin D 2.00', 500, 'btg', 38500, 23500, 'S00009'),
('PWD003', 'Pipa PVC Wavin D 2.50', 500, 'btg', 47550, 32550, 'S00009'),
('PWD004', 'Pipa PVC Wavin D 3.00', 500, 'btg', 58500, 43500, 'S00009'),
('PWD005', 'Pipa PVC Wavin D 4.00', 500, 'btg', 88500, 73500, 'S00009'),
('PWD006', 'Pipa PVC Wavin D 5.00', 500, 'btg', 143500, 128500, 'S00009'),
('PWD007', 'Pipa PVC Wavin D 6.00', 500, 'btg', 184500, 169500, 'S00009'),
('PWD008', 'Pipa PVC Wavin D 8.00', 500, 'btg', 326550, 311550, 'S00009'),
('PWD009', 'Pipa PVC Wavin D 10.00', 500, 'btg', 632550, 617550, 'S00009'),
('SHC001', 'Semen Holcim (40 kg)', 499, 'pcs', 65000, 60000, 'S00001'),
('SHC002', 'Semen Holcim (50 kg)', 498, 'pcs', 75000, 70000, 'S00001'),
('SPD001', 'Semen Padang (50 kg)', 499, 'pcs', 65000, 60000, 'S00001'),
('STR001', 'Semen Tiga Roda (50 kg)', 497, 'pcs', 70000, 65000, 'S00001'),
('TRP001', 'Triplek Tebal (3 mm)', 499, 'lbr', 40000, 35000, 'S00004'),
('TRP002', 'Triplek Tebal (4 mm)', 499, 'lbr', 50000, 45000, 'S00004'),
('TRP003', 'Triplek Tebal (6 mm)', 498, 'lbr', 65000, 60000, 'S00004'),
('TRP004', 'Triplek Tebal (9 mm)', 498, 'lbr', 100000, 95000, 'S00004'),
('TRP005', 'Triplek Tebal (12 mm)', 498, 'lbr', 135000, 130000, 'S00004'),
('TRP006', 'Triplek Tebal (15 mm) ', 500, 'lbr', 175000, 170000, 'S00004'),
('TRP007', 'Triplek Tebal (18 mm)', 500, 'lbr', 195000, 190000, 'S00004');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id_tranksaksi` varchar(20) NOT NULL,
  `id_barang` varchar(6) NOT NULL,
  `qty` double NOT NULL,
  `id_satuan` varchar(6) NOT NULL,
  `total_harga` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `detail_tranksaksi`
--

CREATE TABLE `detail_tranksaksi` (
  `id_tranksaksi` varchar(20) NOT NULL,
  `id_barang` varchar(6) NOT NULL,
  `qty` double NOT NULL,
  `id_satuan` varchar(6) NOT NULL,
  `harga_total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Triggers `detail_tranksaksi`
--
DELIMITER $$
CREATE TRIGGER `STOK` AFTER INSERT ON `detail_tranksaksi` FOR EACH ROW BEGIN
 UPDATE barang SET jumlah=jumlah-NEW.qty
 WHERE id_barang=NEW.id_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `satuan`
--

CREATE TABLE `satuan` (
  `id_satuan` varchar(6) NOT NULL,
  `Jenis` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `satuan`
--

INSERT INTO `satuan` (`id_satuan`, `Jenis`) VALUES
('btg', 'Batang'),
('cm', 'CentiMeter'),
('dus', 'Dus'),
('gr', 'Gram'),
('gros', 'Gros'),
('kg', 'kilogram'),
('kodi', 'Kodi'),
('lbr', 'lembar'),
('lusin', 'Lusin'),
('m', 'meter'),
('m2', 'meter persegi'),
('m3', 'meter kubik'),
('mm', 'MiliMeter'),
('ons', 'Ons'),
('pcs', 'Pieces'),
('rim', 'Rim');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id_supplier` varchar(6) NOT NULL,
  `nama_supplier` varchar(30) NOT NULL,
  `alamat_supplier` varchar(80) NOT NULL,
  `telp_supplier` char(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `alamat_supplier`, `telp_supplier`) VALUES
('S00001', 'Popo', 'Bubulan,Bojonegoro', '081217634111'),
('S00002', 'Wishal', 'Mangil,Jember', '082232937743'),
('S00003', 'Karen', 'Jagalan,Solo', '083864672711'),
('S00004', 'Erik', 'Kepatihan,Jember', '082228455809'),
('S00005', 'Putra', 'Bungatan.Situbondo', '082333564179'),
('S00006', 'Satria', 'Situbondo,Situbondo', '082332991989'),
('S00007', 'Nila', 'Balongpanggang,Gresik', '089504395516'),
('S00008', 'Andru', 'Pasanggaran,Banyuwangi', '85232398005'),
('S00009', 'Ammar', 'Sampusari,Jember', '085335362801'),
('S00010', 'Daffa', 'Banyuanyar,Probolinggo', '089522687919');

-- --------------------------------------------------------

--
-- Table structure for table `tranksaksi`
--

CREATE TABLE `tranksaksi` (
  `id_tranksaksi` varchar(20) NOT NULL,
  `tanggal_tranksaksi` date NOT NULL,
  `jam_transaksi` time NOT NULL,
  `total_bayar` double NOT NULL,
  `uang` double NOT NULL,
  `kembalian` double NOT NULL,
  `id_anggota` varchar(6) NOT NULL,
  `nama_pembeli` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `akun`
--
ALTER TABLE `akun`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indexes for table `anggota`
--
ALTER TABLE `anggota`
  ADD PRIMARY KEY (`id_pengguna`),
  ADD KEY `id_pengguna` (`id_pengguna`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_satuan` (`id_satuan`,`id_sup`),
  ADD KEY `id_sup` (`id_sup`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `detail_tranksaksi`
--
ALTER TABLE `detail_tranksaksi`
  ADD KEY `id_tranksaksi` (`id_tranksaksi`,`id_barang`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `satuan` (`id_satuan`);

--
-- Indexes for table `satuan`
--
ALTER TABLE `satuan`
  ADD PRIMARY KEY (`id_satuan`),
  ADD KEY `id_satuan` (`id_satuan`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id_supplier`),
  ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `tranksaksi`
--
ALTER TABLE `tranksaksi`
  ADD PRIMARY KEY (`id_tranksaksi`),
  ADD KEY `id_tranksaksi` (`id_tranksaksi`),
  ADD KEY `id_anggota` (`id_anggota`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `anggota`
--
ALTER TABLE `anggota`
  ADD CONSTRAINT `anggota_ibfk_1` FOREIGN KEY (`id_pengguna`) REFERENCES `akun` (`id_pengguna`);

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_sup`) REFERENCES `supplier` (`id_supplier`),
  ADD CONSTRAINT `barang_ibfk_2` FOREIGN KEY (`id_satuan`) REFERENCES `satuan` (`id_satuan`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);

--
-- Constraints for table `detail_tranksaksi`
--
ALTER TABLE `detail_tranksaksi`
  ADD CONSTRAINT `detail_tranksaksi_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  ADD CONSTRAINT `detail_tranksaksi_ibfk_2` FOREIGN KEY (`id_tranksaksi`) REFERENCES `tranksaksi` (`id_tranksaksi`) ON DELETE CASCADE;

--
-- Constraints for table `tranksaksi`
--
ALTER TABLE `tranksaksi`
  ADD CONSTRAINT `tranksaksi_ibfk_1` FOREIGN KEY (`id_anggota`) REFERENCES `akun` (`id_pengguna`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
