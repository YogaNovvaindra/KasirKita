Notes : 
	*Aplikasi ini menggunakan java JDK 8 dan MariaDB v10.4.21, pastikan program tersebut sudah berjalan di komputer anda
	*Untuk komputer yang memiliki antivirus, mohon untuk menambahkan pengecualian untuk aplikasi ini
How to Run : 
	1. Ekstrak semua file.
	2. Import script toko_bangunan.sql kedalam database.
	3. jalan aplikasi KasirKita.exe
	4. Default user adalah admin dan password admin
	5. Demi keamanan data, Silahkan buat user baru dengan user tipe dan hapus default user.

Support : 62 896-1518-4146 (agim)